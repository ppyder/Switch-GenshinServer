﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Windows.Forms;
using System.IO;

namespace SwitchGenshin
{
    internal class Program
    {
        // 字典中存放的值
        struct Value
        {
            public Value(string Str, long Index) 
            {
                value = Str;
                index = Index;
            }
            public string value;
            public long index;
        }

        /// <summary>
        /// 参数容器
        /// </summary>
        class ParamContainer : Dictionary<string, Value>
        {
            /// <summary>
            /// 不允许无参数初始化
            /// </summary>
            private ParamContainer() { }

            /// <summary>
            /// 初始化参数容器
            /// </summary>
            /// <param name="name">该容器的标签，也就是名称</param>
            /// <param name="index">该名称在文件中的索引位置</param>
            public ParamContainer(string value, long index)
            {
                Value = value;
                Index = index;
            }

            /// <summary>
            /// 此参数集合的名称
            /// </summary>
            public string Value { get; }
            /// <summary>
            /// 此参数集合在文件中的位置
            /// </summary>
            public long Index { get; }
        }

        // Windows通用换行符
        private const string CRLF = "\r\n";

        // 配置文件路径
        private static readonly string MyconfigAddr = @".\config.ini";

        // 资源文件路径
        private static readonly string ResourcesAddr = @".\Resources\";

        // 动态链接库文件名
        private static readonly string DllName = "PCGameSDK.dll";

        // 初始化配置文件名
        private static readonly string ConfigName = "config.ini";

        // 软件文件夹名
        private static readonly string SoftwareName = "Genshin Impact";

        // 软件路径
        private static readonly string SoftwareDir = @"D:\ProgramFiles_Mine\" + SoftwareName + @"\";

        // 文件PCGameSDK.dll所在位置（承接软件路径）
        private static readonly string DllDir = @"Genshin Impact Game\YuanShen_Data\Plugins\";

        // 文件config.ini所在位置（承接软件路径）
        private static readonly string ConfigDir = @"Genshin Impact Game\";


        static void Main(string[] args)
        {
            /// 暂时想到的是全部写入的方法。
            /// 如果是大文件，这种将文件全部内容读到内存里的做法不可取，需要研究一下。
            /// 尤其是文件中间插入文字的办法。

            bool isBilibili = true;

            bool isToSwitch = false;

            FileStream MyConfigStream;
            FileStream ConfigStream;
            StreamReader sr;
            StreamWriter sw;

            // 基本信息显示
            WriteLine("--- Powered by ppyder ++ 942041771@qq.com ---\n");

            // 创建资源目录,如果目录存在则不创建，返回已存在的目录信息
            DirectoryInfo info = Directory.CreateDirectory(ResourcesAddr);

            // 创建初始化文件，如果存在则不创建，返回已存在的文件句柄（可读可写）
            MyConfigStream = File.Open(MyconfigAddr, FileMode.OpenOrCreate);

            // TODO：读取配置，初始化处理对象路径


            if (Directory.Exists(ResourcesAddr))
            {
                WriteLine("资源文件路径确认有效。\n");
            }
            else
            {
                WriteLine("资源文件路径不存在。\n");
            }

            if (Directory.Exists(SoftwareDir))
            {
                WriteLine("软件安装路径确认有效。\n");
            }
            else
            {
                WriteLine("软件安装路径不存在，请执行一次将软件所在文件夹拖动到本软件图标上的操作。\n");
            }

            if (Directory.Exists(SoftwareDir + DllDir) && Directory.Exists(SoftwareDir + ConfigDir))
            {
                WriteLine("其他路径确认有效。\n");
            }
            else
            {
                WriteLine("存在无效的其他路径，请联系软件作者升级软件。\n");
            }

            // 创建一个参数容器
            Dictionary<string, ParamContainer> Params = new Dictionary<string, ParamContainer>();

            // 打开原神的初始化文件
            try
            {
                // 获得文件流
                ConfigStream = File.Open(SoftwareDir + ConfigDir + ConfigName, FileMode.Open, FileAccess.ReadWrite);
                // 获得文件的读取流
                sr = new StreamReader(ConfigStream, Encoding.GetEncoding("utf-8"));

                // 读取文件并初始化获得的参数
                string line, name, value, temp;
                long index = 0;
                ParamContainer TempPC = null;
                while ((line = sr.ReadLine()) != null)
                {
                    // 保存原读取结果
                    temp = line;

                    // 如果这是一个关键字行
                    if (line.Contains("[") && line.Contains("]"))
                    {
                        name = line.Substring(1, line.IndexOf("]") - 1);
                        TempPC = new ParamContainer(name, index);

                        // 为这个关键字创建一个与之对应的参数容器
                        Params.Add(name, TempPC);
                    }
                    else // 如果这是一个参数行
                    {
                        // 参数名称是等号前的部分
                        name = line.Substring(0, line.IndexOf("="));
                        // 参数值是等号后的部分
                        value = line.Substring(line.IndexOf("=") + 1);

                        if(TempPC is null)
                        {
                            // 防止有的配置文件没写头，全是一个参数组合
                            TempPC = new ParamContainer("Globle", 0);
                        }

                        // 将关键字添加在对应的关键字容器中
                        TempPC.Add(name, new Value(value, index));
                    }
                    // 更新读取位置(要算上结尾的CRLF)
                    index += temp.Length + CRLF.Length;
                }
                // 释放资源
                sr.Close();
                ConfigStream.Close();
            }
            catch (Exception ex)
            {
                Write("\n" + ex.ToString());
            }

            // TODO：进行格式检查（防止内容格式发生变化，本软件版本落后导致的问题）

            // test显示输入参数
            foreach (string arg in args)
            {
                WriteLine(arg);
                if (arg.EndsWith(DllName))
                {
                    try
                    {
                        // 将目标文件放在软件目录下
                        File.Copy(arg, ResourcesAddr + DllName);

                        // 从文件路径截取软件路径
                        DirectoryInfo TempInfo = new DirectoryInfo(arg.Replace(DllName, ""));
                        string SoftwarePath = TempInfo.Parent.Parent.Parent.FullName;

                        if(!SoftwarePath.EndsWith(SoftwareName))
                        {
                            // 文件夹结构已经发生改变，需要升级软件
                        }

                        // TODO：将软件目录保存在本地

                    }
                    catch (Exception ex)
                    {
                        Write("\n" + ex.ToString());
                    }

                    // TODO：验证有效性，并在配置文件中记录此路径

                }
                else if (arg.EndsWith(SoftwareName))
                {
                    // TODO：验证有效性，在配置文件中保存软件安装目录
                    // 检查本地DLL存在性，检查目标目录DLL存在性，若有，则计算MD5校验值是否匹配
                }
            }

            // 查询软件当前状态(1.PCGameSDK.dll存在，2.config.ini中的[General]channel = 14，cps = bilibili即为bilibil登录)
            isBilibili = File.Exists(SoftwareDir + DllDir + DllName) && 
                        (Params["General"]["channel"].value == "14" && Params["General"]["cps"].value == "bilibili");

            // 询问是否切换
            if (MessageBox.Show("目前的服务器选项是 [" + (isBilibili ? "Bilibili" : "Mihoyo") + "]，确定要切换吗？",
                                "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                WriteLine("\n选择了\"是\"。");
                isToSwitch = true;
            }
            else
            {
                WriteLine("\n选择了\"否\"。");
                isToSwitch = false;

                // 直接结束程序
                return;
            }

            try
            {
                // 获得文件流(覆写原文件)
                ConfigStream = File.Open(SoftwareDir + ConfigDir + ConfigName, FileMode.Create, FileAccess.ReadWrite);
                // 获得文件的读取流
                sw = new StreamWriter(ConfigStream);//, Encoding.GetEncoding("utf-8"));

                if (isToSwitch)
                {
                    if (isBilibili ? SwitchToMiHoYo(ref Params) : SwitchToBiliBili(ref Params))
                    {
                        isBilibili = !isBilibili;
                    }
                    else
                    {
                        WriteLine("\n切换时出错，请联系作者排错。");
                    }
                }
                // 清空文件
                

                // 将变更后的配置写入文件
                foreach (KeyValuePair<string, ParamContainer> pc in Params)
                {
                    sw.Write("[" + pc.Value.Value + "]" + CRLF);
                    foreach (KeyValuePair<string, Value> val in pc.Value)
                    {
                        sw.Write(val.Key + "=" + val.Value.value + CRLF);
                    }
                }
                //sw.Write(Convert.ToChar(0x04));
                // 释放资源
                sw.Close();
                ConfigStream.Close();

                //根据标志给出提示
                MessageBox.Show($"Done！已切换为 [" + (isBilibili ? "Bilibili" : "Mihoyo") + "] 服务器登录！", "玩得开心！");
            }
            catch (Exception ex)
            {
                Write("\n" + ex.ToString());
            }
            


            return;
        }

        static bool SwitchToBiliBili(ref Dictionary<string, ParamContainer> Params)
        {
            // 将DLL拷贝到对应目录
            File.Copy(ResourcesAddr + DllName, SoftwareDir + DllDir + DllName);

            // 更改配置文件信道
            Params["General"]["channel"] = new Value("14", Params["General"]["channel"].index);
            Params["General"]["cps"] = new Value("bilibili", Params["General"]["cps"].index);

            return true;
        }

        static bool SwitchToMiHoYo(ref Dictionary<string, ParamContainer> Params)
        {
            // 移除对应的DLL
            File.Delete(SoftwareDir + DllDir + DllName);

            // 更改配置文件信道
            Params["General"]["channel"] = new Value("1", Params["General"]["channel"].index);
            Params["General"]["cps"] = new Value("mihoyo", Params["General"]["cps"].index);

            return true;
        }
    }
}
